<?php

namespace App\Enum;

enum GenderEnum: string
{
    case MALE = 'male';
    case FEMELLE = 'femelle';
}