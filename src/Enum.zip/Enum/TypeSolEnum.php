<?php

namespace App\Enum;

enum TypeSolEnum: string
{
    case ARGILE = 'argile';
    case SABLE = 'sable';
    case LIMON = 'limon';
    case CALCAIRE = 'calcaire';
    case TERRE_NOIRE = 'terre_noire';
}